/**
 * TaskFlow — Node.js + SQLite Backend
 * Run: npm install && node server.js
 * API base: http://localhost:3001/api
 */

const express = require("express");
const sqlite3 = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || "taskflow-secret-change-in-prod";

app.use(cors({ origin: "http://localhost:3000", credentials: true }));
app.use(express.json());

// ─── DATABASE SETUP ──────────────────────────────────────────────────────────

const db = new sqlite3(path.join(__dirname, "taskflow.db"));

db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS users (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL,
    email       TEXT    NOT NULL UNIQUE,
    password    TEXT    NOT NULL,
    role        TEXT    NOT NULL DEFAULT 'member' CHECK(role IN ('leader','member')),
    avatar      TEXT,
    color       TEXT    DEFAULT '#6366f1',
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT    NOT NULL,
    description TEXT,
    assignee_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    deadline    TEXT,
    priority    TEXT    NOT NULL DEFAULT 'medium' CHECK(priority IN ('critical','high','medium','low')),
    status      TEXT    NOT NULL DEFAULT 'todo' CHECK(status IN ('todo','in-progress','completed')),
    category    TEXT    NOT NULL DEFAULT 'Engineering',
    created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS activity_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER REFERENCES users(id),
    task_id     INTEGER REFERENCES tasks(id) ON DELETE CASCADE,
    action      TEXT    NOT NULL,
    detail      TEXT,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
  );
`);

// ─── SEED DATA (runs once if users table is empty) ────────────────────────────

const userCount = db.prepare("SELECT COUNT(*) as c FROM users").get().c;
if (userCount === 0) {
  const insert = db.prepare(
    "INSERT INTO users (name, email, password, role, avatar, color) VALUES (?, ?, ?, ?, ?, ?)"
  );
  const insertTask = db.prepare(`
    INSERT INTO tasks (title, description, assignee_id, created_by, deadline, priority, status, category)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const users = [
    ["Alex Rivera",  "alex@team.io",   bcrypt.hashSync("leader123", 10), "leader", "AR", "#4f46e5"],
    ["Jordan Kim",   "jordan@team.io", bcrypt.hashSync("member123", 10), "member", "JK", "#0891b2"],
    ["Sam Patel",    "sam@team.io",    bcrypt.hashSync("member456", 10), "member", "SP", "#059669"],
    ["Morgan Lee",   "morgan@team.io", bcrypt.hashSync("member789", 10), "member", "ML", "#d97706"],
  ];
  const ids = users.map(u => insert.run(...u).lastInsertRowid);
  const [leaderId, jordanId, samId, morganId] = ids;

  [
    ["Design system audit",    "Review all components for consistency", jordanId, leaderId, "2026-05-20", "high",     "in-progress", "Design"],
    ["API integration docs",   "Write comprehensive API documentation",  samId,    leaderId, "2026-05-18", "medium",   "completed",   "Engineering"],
    ["Q2 analytics report",    "Compile Q2 performance metrics",         jordanId, leaderId, "2026-05-25", "high",     "todo",        "Analytics"],
    ["User onboarding flow",   "Redesign the onboarding experience",     morganId, leaderId, "2026-06-01", "medium",   "in-progress", "Design"],
    ["Database optimization",  "Optimize slow queries in production",    samId,    leaderId, "2026-05-16", "critical", "completed",   "Engineering"],
    ["Competitor analysis",    "Research top 5 competitors' features",   morganId, leaderId, "2026-05-22", "low",      "todo",        "Research"],
    ["Sprint retrospective",   "Facilitate team retrospective meeting",  jordanId, leaderId, "2026-05-15", "medium",   "completed",   "Management"],
    ["Security audit",         "Run security vulnerability scan",        samId,    leaderId, "2026-05-30", "critical", "todo",        "Engineering"],
  ].forEach(t => insertTask.run(...t));

  console.log("✅ Database seeded with demo data");
}

// ─── MIDDLEWARE ───────────────────────────────────────────────────────────────

function requireAuth(req, res, next) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "No token provided" });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Invalid or expired token" });
  }
}

function requireLeader(req, res, next) {
  if (req.user.role !== "leader")
    return res.status(403).json({ error: "Leader access required" });
  next();
}

function log(userId, taskId, action, detail = "") {
  db.prepare("INSERT INTO activity_log (user_id, task_id, action, detail) VALUES (?, ?, ?, ?)").run(userId, taskId, action, detail);
}

// ─── AUTH ROUTES ──────────────────────────────────────────────────────────────

/** POST /api/auth/login */
app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(400).json({ error: "Email and password required" });

  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if (!user || !bcrypt.compareSync(password, user.password))
    return res.status(401).json({ error: "Invalid credentials" });

  const token = jwt.sign(
    { id: user.id, name: user.name, email: user.email, role: user.role, avatar: user.avatar, color: user.color },
    JWT_SECRET,
    { expiresIn: "7d" }
  );
  const { password: _, ...safeUser } = user;
  res.json({ token, user: safeUser });
});

/** GET /api/auth/me */
app.get("/api/auth/me", requireAuth, (req, res) => {
  const user = db.prepare("SELECT id,name,email,role,avatar,color,created_at FROM users WHERE id=?").get(req.user.id);
  user ? res.json(user) : res.status(404).json({ error: "User not found" });
});

// ─── USER ROUTES ──────────────────────────────────────────────────────────────

/** GET /api/users — Leaders see all, members see themselves */
app.get("/api/users", requireAuth, (req, res) => {
  if (req.user.role === "leader") {
    const users = db.prepare("SELECT id,name,email,role,avatar,color,created_at FROM users").all();
    res.json(users);
  } else {
    const user = db.prepare("SELECT id,name,email,role,avatar,color,created_at FROM users WHERE id=?").get(req.user.id);
    res.json([user]);
  }
});

/** POST /api/users — Leader creates a new user */
app.post("/api/users", requireAuth, requireLeader, (req, res) => {
  const { name, email, password, role = "member", color = "#6366f1" } = req.body;
  if (!name || !email || !password)
    return res.status(400).json({ error: "name, email, and password are required" });

  const avatar = name.split(" ").map(p => p[0]).join("").toUpperCase().slice(0, 2);
  const hashed = bcrypt.hashSync(password, 10);
  try {
    const { lastInsertRowid: id } = db.prepare(
      "INSERT INTO users (name,email,password,role,avatar,color) VALUES (?,?,?,?,?,?)"
    ).run(name, email, hashed, role, avatar, color);
    res.status(201).json({ id, name, email, role, avatar, color });
  } catch (e) {
    if (e.message.includes("UNIQUE")) return res.status(409).json({ error: "Email already in use" });
    throw e;
  }
});

/** PATCH /api/users/:id/password — Change own password */
app.patch("/api/users/:id/password", requireAuth, (req, res) => {
  const targetId = Number(req.params.id);
  if (req.user.role !== "leader" && req.user.id !== targetId)
    return res.status(403).json({ error: "Forbidden" });
  const { password } = req.body;
  if (!password || password.length < 6)
    return res.status(400).json({ error: "Password must be at least 6 characters" });
  db.prepare("UPDATE users SET password=? WHERE id=?").run(bcrypt.hashSync(password, 10), targetId);
  res.json({ success: true });
});

/** DELETE /api/users/:id */
app.delete("/api/users/:id", requireAuth, requireLeader, (req, res) => {
  const id = Number(req.params.id);
  if (id === req.user.id) return res.status(400).json({ error: "Cannot delete yourself" });
  db.prepare("DELETE FROM users WHERE id=?").run(id);
  res.json({ success: true });
});

// ─── TASK ROUTES ──────────────────────────────────────────────────────────────

const TASK_COLS = "t.id, t.title, t.description, t.assignee_id, t.created_by, t.deadline, t.priority, t.status, t.category, t.created_at, t.updated_at, u.name as assignee_name, u.avatar as assignee_avatar, u.color as assignee_color";
const TASK_JOIN = "FROM tasks t LEFT JOIN users u ON u.id = t.assignee_id";

/** GET /api/tasks */
app.get("/api/tasks", requireAuth, (req, res) => {
  const { status, priority, category, search, assigneeId } = req.query;
  let where = req.user.role === "member" ? `WHERE t.assignee_id = ${req.user.id}` : "WHERE 1=1";
  const params = [];

  if (status)     { where += " AND t.status = ?";    params.push(status); }
  if (priority)   { where += " AND t.priority = ?";  params.push(priority); }
  if (category)   { where += " AND t.category = ?";  params.push(category); }
  if (assigneeId) { where += " AND t.assignee_id = ?"; params.push(assigneeId); }
  if (search)     { where += " AND t.title LIKE ?";  params.push(`%${search}%`); }

  const tasks = db.prepare(`SELECT ${TASK_COLS} ${TASK_JOIN} ${where} ORDER BY t.created_at DESC`).all(...params);
  res.json(tasks);
});

/** GET /api/tasks/:id */
app.get("/api/tasks/:id", requireAuth, (req, res) => {
  const task = db.prepare(`SELECT ${TASK_COLS} ${TASK_JOIN} WHERE t.id = ?`).get(req.params.id);
  if (!task) return res.status(404).json({ error: "Task not found" });
  if (req.user.role === "member" && task.assignee_id !== req.user.id)
    return res.status(403).json({ error: "Forbidden" });
  res.json(task);
});

/** POST /api/tasks — Leaders only */
app.post("/api/tasks", requireAuth, requireLeader, (req, res) => {
  const { title, description = "", assigneeId, deadline, priority = "medium", category = "Engineering", status = "todo" } = req.body;
  if (!title) return res.status(400).json({ error: "Title is required" });

  const { lastInsertRowid: id } = db.prepare(`
    INSERT INTO tasks (title, description, assignee_id, created_by, deadline, priority, category, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(title, description, assigneeId || null, req.user.id, deadline || null, priority, category, status);

  log(req.user.id, id, "created", `Created task "${title}"`);
  const task = db.prepare(`SELECT ${TASK_COLS} ${TASK_JOIN} WHERE t.id = ?`).get(id);
  res.status(201).json(task);
});

/** PATCH /api/tasks/:id — Leaders update anything; members can only update status of their own tasks */
app.patch("/api/tasks/:id", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  const task = db.prepare("SELECT * FROM tasks WHERE id=?").get(id);
  if (!task) return res.status(404).json({ error: "Task not found" });

  if (req.user.role === "member") {
    if (task.assignee_id !== req.user.id) return res.status(403).json({ error: "Forbidden" });
    const { status } = req.body;
    if (!status) return res.status(400).json({ error: "Members can only update status" });
    db.prepare("UPDATE tasks SET status=?, updated_at=datetime('now') WHERE id=?").run(status, id);
    log(req.user.id, id, "status_changed", `Status → ${status}`);
  } else {
    const allowed = ["title","description","assignee_id","deadline","priority","status","category"];
    const fields = Object.entries(req.body).filter(([k]) => allowed.includes(k));
    if (fields.length === 0) return res.status(400).json({ error: "No valid fields provided" });
    const setClauses = fields.map(([k]) => `${k}=?`).join(", ");
    const values = fields.map(([, v]) => v);
    db.prepare(`UPDATE tasks SET ${setClauses}, updated_at=datetime('now') WHERE id=?`).run(...values, id);
    log(req.user.id, id, "updated", `Updated: ${fields.map(([k]) => k).join(", ")}`);
  }

  const updated = db.prepare(`SELECT ${TASK_COLS} ${TASK_JOIN} WHERE t.id = ?`).get(id);
  res.json(updated);
});

/** DELETE /api/tasks/:id — Leaders only */
app.delete("/api/tasks/:id", requireAuth, requireLeader, (req, res) => {
  const id = Number(req.params.id);
  const task = db.prepare("SELECT title FROM tasks WHERE id=?").get(id);
  if (!task) return res.status(404).json({ error: "Task not found" });
  db.prepare("DELETE FROM tasks WHERE id=?").run(id);
  log(req.user.id, id, "deleted", `Deleted task "${task.title}"`);
  res.json({ success: true });
});

// ─── ANALYTICS ROUTES ─────────────────────────────────────────────────────────

/** GET /api/analytics/summary — Leaders only */
app.get("/api/analytics/summary", requireAuth, requireLeader, (req, res) => {
  const total    = db.prepare("SELECT COUNT(*) as c FROM tasks").get().c;
  const done     = db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status='completed'").get().c;
  const inProg   = db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status='in-progress'").get().c;
  const todo     = db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status='todo'").get().c;
  const overdue  = db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status!='completed' AND deadline < date('now')").get().c;

  const byMember = db.prepare(`
    SELECT u.id, u.name, u.color, u.avatar,
           COUNT(t.id) as total,
           SUM(CASE WHEN t.status='completed' THEN 1 ELSE 0 END) as done
    FROM users u LEFT JOIN tasks t ON t.assignee_id = u.id
    WHERE u.role='member' GROUP BY u.id
  `).all();

  const byCategory = db.prepare(`
    SELECT category, COUNT(*) as count FROM tasks GROUP BY category ORDER BY count DESC
  `).all();

  const byPriority = db.prepare(`
    SELECT priority, COUNT(*) as count FROM tasks GROUP BY priority
  `).all();

  const recentActivity = db.prepare(`
    SELECT al.action, al.detail, al.created_at, u.name as user_name
    FROM activity_log al LEFT JOIN users u ON u.id = al.user_id
    ORDER BY al.created_at DESC LIMIT 20
  `).all();

  res.json({
    overview: { total, done, inProg, todo, overdue, rate: total > 0 ? Math.round((done / total) * 100) : 0 },
    byMember: byMember.map(m => ({ ...m, pct: m.total > 0 ? Math.round((m.done / m.total) * 100) : 0 })),
    byCategory,
    byPriority,
    recentActivity,
  });
});

/** GET /api/analytics/my — Member's own stats */
app.get("/api/analytics/my", requireAuth, (req, res) => {
  const uid = req.user.id;
  const total  = db.prepare("SELECT COUNT(*) as c FROM tasks WHERE assignee_id=?").get(uid).c;
  const done   = db.prepare("SELECT COUNT(*) as c FROM tasks WHERE assignee_id=? AND status='completed'").get(uid).c;
  const inProg = db.prepare("SELECT COUNT(*) as c FROM tasks WHERE assignee_id=? AND status='in-progress'").get(uid).c;
  const overdue = db.prepare("SELECT COUNT(*) as c FROM tasks WHERE assignee_id=? AND status!='completed' AND deadline < date('now')").get(uid).c;
  res.json({ total, done, inProg, todo: total - done - inProg, overdue, rate: total > 0 ? Math.round((done/total)*100) : 0 });
});

// ─── ACTIVITY LOG ─────────────────────────────────────────────────────────────

/** GET /api/activity */
app.get("/api/activity", requireAuth, requireLeader, (req, res) => {
  const rows = db.prepare(`
    SELECT al.*, u.name as user_name, t.title as task_title
    FROM activity_log al
    LEFT JOIN users u ON u.id = al.user_id
    LEFT JOIN tasks t ON t.id = al.task_id
    ORDER BY al.created_at DESC LIMIT 50
  `).all();
  res.json(rows);
});

// ─── START ────────────────────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`
  ⚡ TaskFlow API running on http://localhost:${PORT}
  
  Endpoints:
    POST   /api/auth/login
    GET    /api/auth/me
    GET    /api/users
    POST   /api/users          (leader)
    DELETE /api/users/:id      (leader)
    GET    /api/tasks
    POST   /api/tasks          (leader)
    PATCH  /api/tasks/:id
    DELETE /api/tasks/:id      (leader)
    GET    /api/analytics/summary (leader)
    GET    /api/analytics/my
    GET    /api/activity       (leader)

  Demo logins:
    alex@team.io   / leader123  [Team Leader]
    jordan@team.io / member123  [Member]
    sam@team.io    / member456  [Member]
    morgan@team.io / member789  [Member]
  `);
});

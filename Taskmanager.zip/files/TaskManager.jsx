import { useState, useEffect, useRef, useMemo } from "react";

const DB = {
  users: [
    { id: 1, name: "Alex Rivera", email: "alex@team.io", password: "leader123", role: "leader", avatar: "AR", color: "#4f46e5" },
    { id: 2, name: "Jordan Kim", email: "jordan@team.io", password: "member123", role: "member", avatar: "JK", color: "#0891b2" },
    { id: 3, name: "Sam Patel", email: "sam@team.io", password: "member456", role: "member", avatar: "SP", color: "#059669" },
    { id: 4, name: "Morgan Lee", email: "morgan@team.io", password: "member789", role: "member", avatar: "ML", color: "#d97706" },
  ],
  tasks: [
    { id: 1, title: "Design system audit", description: "Review all components for consistency", assigneeId: 2, createdBy: 1, deadline: "2026-05-20", priority: "high", status: "in-progress", category: "Design", createdAt: "2026-05-01" },
    { id: 2, title: "API integration docs", description: "Write comprehensive API documentation", assigneeId: 3, createdBy: 1, deadline: "2026-05-18", priority: "medium", status: "completed", category: "Engineering", createdAt: "2026-05-02" },
    { id: 3, title: "Q2 analytics report", description: "Compile and analyze Q2 performance metrics", assigneeId: 2, createdBy: 1, deadline: "2026-05-25", priority: "high", status: "todo", category: "Analytics", createdAt: "2026-05-03" },
    { id: 4, title: "User onboarding flow", description: "Redesign the onboarding experience", assigneeId: 4, createdBy: 1, deadline: "2026-06-01", priority: "medium", status: "in-progress", category: "Design", createdAt: "2026-05-04" },
    { id: 5, title: "Database optimization", description: "Optimize slow queries in production", assigneeId: 3, createdBy: 1, deadline: "2026-05-16", priority: "critical", status: "completed", category: "Engineering", createdAt: "2026-05-05" },
    { id: 6, title: "Competitor analysis", description: "Research top 5 competitors' features", assigneeId: 4, createdBy: 1, deadline: "2026-05-22", priority: "low", status: "todo", category: "Research", createdAt: "2026-05-06" },
    { id: 7, title: "Sprint retrospective", description: "Facilitate team retrospective meeting", assigneeId: 2, createdBy: 1, deadline: "2026-05-15", priority: "medium", status: "completed", category: "Management", createdAt: "2026-05-07" },
    { id: 8, title: "Security audit", description: "Run security vulnerability scan", assigneeId: 3, createdBy: 1, deadline: "2026-05-30", priority: "critical", status: "todo", category: "Engineering", createdAt: "2026-05-08" },
  ],
};

let nextTaskId = 9;

const PRIORITIES = { critical: { label: "Critical", color: "#ef4444", bg: "#fef2f2" }, high: { label: "High", color: "#f97316", bg: "#fff7ed" }, medium: { label: "Medium", color: "#eab308", bg: "#fefce8" }, low: { label: "Low", color: "#22c55e", bg: "#f0fdf4" } };
const STATUSES = { todo: { label: "To Do", color: "#6b7280", bg: "#f3f4f6" }, "in-progress": { label: "In Progress", color: "#3b82f6", bg: "#eff6ff" }, completed: { label: "Completed", color: "#10b981", bg: "#ecfdf5" } };
const CATEGORIES = ["Design", "Engineering", "Analytics", "Research", "Management", "Marketing", "Other"];

function Avatar({ user, size = 36 }) {
  return (
    <div style={{ width: size, height: size, borderRadius: "50%", background: user.color + "22", color: user.color, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 600, fontSize: size * 0.35, flexShrink: 0, border: `1.5px solid ${user.color}44` }}>
      {user.avatar}
    </div>
  );
}

function Badge({ type, value, map }) {
  const cfg = map[value] || {};
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "2px 8px", borderRadius: 20, fontSize: 11, fontWeight: 600, background: cfg.bg || "#f3f4f6", color: cfg.color || "#6b7280", letterSpacing: "0.02em" }}>
      {cfg.label || value}
    </span>
  );
}

function ProgressRing({ pct, size = 56, stroke = 5, color = "#4f46e5" }) {
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#e5e7eb" strokeWidth={stroke} />
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeDasharray={circ} strokeDashoffset={circ * (1 - pct / 100)} strokeLinecap="round" style={{ transition: "stroke-dashoffset 0.6s ease" }} />
    </svg>
  );
}

function MiniBar({ data, maxVal }) {
  return (
    <div style={{ display: "flex", gap: 4, alignItems: "flex-end", height: 40 }}>
      {data.map((d, i) => (
        <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
          <div style={{ width: "100%", background: d.color + "cc", borderRadius: "3px 3px 0 0", height: `${maxVal > 0 ? (d.val / maxVal) * 36 : 0}px`, minHeight: d.val > 0 ? 3 : 0, transition: "height 0.5s ease" }} />
        </div>
      ))}
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState(null);
  const [tasks, setTasks] = useState(DB.tasks);
  const [page, setPage] = useState("dashboard");
  const [loginForm, setLoginForm] = useState({ email: "", password: "", error: "" });
  const [taskFilter, setTaskFilter] = useState({ status: "all", priority: "all", search: "" });
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [editTask, setEditTask] = useState(null);
  const [taskForm, setTaskForm] = useState({ title: "", description: "", assigneeId: "", deadline: "", priority: "medium", category: "Engineering", status: "todo" });
  const [notification, setNotification] = useState(null);

  const notify = (msg, type = "success") => {
    setNotification({ msg, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const myTasks = user ? tasks.filter(t => user.role === "leader" ? true : t.assigneeId === user.id) : [];

  const stats = useMemo(() => {
    const base = myTasks;
    const total = base.length;
    const done = base.filter(t => t.status === "completed").length;
    const inProg = base.filter(t => t.status === "in-progress").length;
    const todo = base.filter(t => t.status === "todo").length;
    const overdue = base.filter(t => t.status !== "completed" && new Date(t.deadline) < new Date()).length;
    const rate = total > 0 ? Math.round((done / total) * 100) : 0;
    const byMember = DB.users.filter(u => u.role === "member").map(u => {
      const ut = tasks.filter(t => t.assigneeId === u.id);
      const udone = ut.filter(t => t.status === "completed").length;
      return { name: u.name.split(" ")[0], total: ut.length, done: udone, pct: ut.length > 0 ? Math.round((udone / ut.length) * 100) : 0, color: u.color, avatar: u.avatar };
    });
    const byCategory = CATEGORIES.map(c => ({ cat: c, count: base.filter(t => t.category === c).length })).filter(x => x.count > 0);
    return { total, done, inProg, todo, overdue, rate, byMember, byCategory };
  }, [myTasks, tasks]);

  function handleLogin() {
    const found = DB.users.find(u => u.email === loginForm.email && u.password === loginForm.password);
    if (found) { setUser(found); setPage("dashboard"); }
    else setLoginForm(f => ({ ...f, error: "Invalid credentials. Try again." }));
  }

  function handleSaveTask() {
    if (!taskForm.title.trim()) return;
    if (editTask) {
      setTasks(ts => ts.map(t => t.id === editTask.id ? { ...t, ...taskForm, assigneeId: Number(taskForm.assigneeId) } : t));
      notify("Task updated successfully");
    } else {
      const newTask = { ...taskForm, id: nextTaskId++, assigneeId: Number(taskForm.assigneeId) || user.id, createdBy: user.id, createdAt: new Date().toISOString().slice(0, 10) };
      setTasks(ts => [...ts, newTask]);
      notify("Task created successfully");
    }
    setShowTaskModal(false);
    setEditTask(null);
    setTaskForm({ title: "", description: "", assigneeId: "", deadline: "", priority: "medium", category: "Engineering", status: "todo" });
  }

  function openEdit(task) {
    setEditTask(task);
    setTaskForm({ title: task.title, description: task.description, assigneeId: task.assigneeId, deadline: task.deadline, priority: task.priority, category: task.category, status: task.status });
    setShowTaskModal(true);
  }

  function deleteTask(id) {
    setTasks(ts => ts.filter(t => t.id !== id));
    notify("Task deleted", "danger");
  }

  function toggleStatus(task) {
    const next = task.status === "todo" ? "in-progress" : task.status === "in-progress" ? "completed" : "todo";
    setTasks(ts => ts.map(t => t.id === task.id ? { ...t, status: next } : t));
  }

  const filteredTasks = myTasks.filter(t => {
    if (taskFilter.status !== "all" && t.status !== taskFilter.status) return false;
    if (taskFilter.priority !== "all" && t.priority !== taskFilter.priority) return false;
    if (taskFilter.search && !t.title.toLowerCase().includes(taskFilter.search.toLowerCase())) return false;
    return true;
  });

  if (!user) {
    return (
      <div style={{ minHeight: "100vh", background: "linear-gradient(135deg, #0f0c29, #302b63, #24243e)", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Segoe UI', system-ui, sans-serif" }}>
        <div style={{ background: "rgba(255,255,255,0.04)", backdropFilter: "blur(20px)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 20, padding: "48px 40px", width: 380, boxShadow: "0 25px 50px rgba(0,0,0,0.5)" }}>
          <div style={{ textAlign: "center", marginBottom: 32 }}>
            <div style={{ width: 52, height: 52, borderRadius: 14, background: "linear-gradient(135deg, #6366f1, #8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px", fontSize: 24 }}>⚡</div>
            <h1 style={{ color: "#fff", margin: 0, fontSize: 24, fontWeight: 700 }}>TaskFlow</h1>
            <p style={{ color: "rgba(255,255,255,0.5)", margin: "6px 0 0", fontSize: 13 }}>Team Task Management Platform</p>
          </div>
          {loginForm.error && <div style={{ background: "rgba(239,68,68,0.15)", border: "1px solid rgba(239,68,68,0.3)", borderRadius: 10, padding: "10px 14px", color: "#fca5a5", fontSize: 13, marginBottom: 16 }}>{loginForm.error}</div>}
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div>
              <label style={{ color: "rgba(255,255,255,0.6)", fontSize: 12, fontWeight: 500, letterSpacing: "0.05em", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Email</label>
              <input value={loginForm.email} onChange={e => setLoginForm(f => ({ ...f, email: e.target.value, error: "" }))} onKeyDown={e => e.key === "Enter" && handleLogin()} placeholder="your@email.com" style={{ width: "100%", padding: "10px 14px", background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 10, color: "#fff", fontSize: 14, outline: "none", boxSizing: "border-box" }} />
            </div>
            <div>
              <label style={{ color: "rgba(255,255,255,0.6)", fontSize: 12, fontWeight: 500, letterSpacing: "0.05em", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Password</label>
              <input type="password" value={loginForm.password} onChange={e => setLoginForm(f => ({ ...f, password: e.target.value, error: "" }))} onKeyDown={e => e.key === "Enter" && handleLogin()} placeholder="••••••••" style={{ width: "100%", padding: "10px 14px", background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 10, color: "#fff", fontSize: 14, outline: "none", boxSizing: "border-box" }} />
            </div>
            <button onClick={handleLogin} style={{ marginTop: 8, padding: "12px", background: "linear-gradient(135deg, #6366f1, #8b5cf6)", border: "none", borderRadius: 10, color: "#fff", fontSize: 15, fontWeight: 600, cursor: "pointer" }}>Sign In</button>
          </div>
          <div style={{ marginTop: 28, borderTop: "1px solid rgba(255,255,255,0.08)", paddingTop: 20 }}>
            <p style={{ color: "rgba(255,255,255,0.4)", fontSize: 11, textAlign: "center", marginBottom: 12, textTransform: "uppercase", letterSpacing: "0.06em" }}>Demo Accounts</p>
            {DB.users.map(u => (
              <div key={u.id} onClick={() => { setLoginForm({ email: u.email, password: u.password, error: "" }); }} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 10px", borderRadius: 8, cursor: "pointer", transition: "background 0.15s", marginBottom: 4 }} onMouseEnter={e => e.currentTarget.style.background = "rgba(255,255,255,0.06)"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                <Avatar user={u} size={28} />
                <div style={{ flex: 1 }}>
                  <p style={{ color: "#fff", margin: 0, fontSize: 12, fontWeight: 500 }}>{u.name}</p>
                  <p style={{ color: "rgba(255,255,255,0.4)", margin: 0, fontSize: 10 }}>{u.email}</p>
                </div>
                <span style={{ fontSize: 10, padding: "2px 7px", borderRadius: 20, background: u.role === "leader" ? "rgba(99,102,241,0.25)" : "rgba(14,165,233,0.2)", color: u.role === "leader" ? "#a5b4fc" : "#7dd3fc", fontWeight: 600 }}>{u.role}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#f8fafc", fontFamily: "'Segoe UI', system-ui, sans-serif" }}>
      {/* Sidebar */}
      <aside style={{ width: 220, background: "#0f172a", display: "flex", flexDirection: "column", position: "fixed", top: 0, left: 0, bottom: 0, zIndex: 100 }}>
        <div style={{ padding: "24px 20px 16px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: "linear-gradient(135deg, #6366f1, #8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>⚡</div>
            <span style={{ color: "#fff", fontWeight: 700, fontSize: 17 }}>TaskFlow</span>
          </div>
        </div>
        <div style={{ padding: "0 12px", flex: 1 }}>
          {[
            { id: "dashboard", icon: "🏠", label: "Dashboard" },
            { id: "tasks", icon: "✅", label: "Tasks" },
            ...(user.role === "leader" ? [{ id: "analytics", icon: "📊", label: "Analytics" }, { id: "team", icon: "👥", label: "Team" }] : []),
          ].map(item => (
            <button key={item.id} onClick={() => setPage(item.id)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 10, border: "none", background: page === item.id ? "rgba(99,102,241,0.2)" : "transparent", color: page === item.id ? "#a5b4fc" : "rgba(255,255,255,0.5)", fontSize: 13, fontWeight: page === item.id ? 600 : 400, cursor: "pointer", textAlign: "left", marginBottom: 2, transition: "all 0.15s" }}>
              <span style={{ fontSize: 15 }}>{item.icon}</span>{item.label}
            </button>
          ))}
        </div>
        <div style={{ padding: "16px 12px", borderTop: "1px solid rgba(255,255,255,0.06)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 10px", marginBottom: 8 }}>
            <Avatar user={user} size={32} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ color: "#fff", margin: 0, fontSize: 12, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{user.name}</p>
              <p style={{ color: "rgba(255,255,255,0.4)", margin: 0, fontSize: 10 }}>{user.role === "leader" ? "Team Leader" : "Team Member"}</p>
            </div>
          </div>
          <button onClick={() => { setUser(null); setLoginForm({ email: "", password: "", error: "" }); }} style={{ width: "100%", padding: "8px", background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)", borderRadius: 8, color: "#fca5a5", fontSize: 12, cursor: "pointer" }}>Sign Out</button>
        </div>
      </aside>

      {/* Main */}
      <main style={{ marginLeft: 220, flex: 1, padding: "28px 32px", minHeight: "100vh" }}>
        {notification && (
          <div style={{ position: "fixed", top: 20, right: 20, zIndex: 999, background: notification.type === "danger" ? "#ef4444" : "#10b981", color: "#fff", padding: "10px 18px", borderRadius: 10, fontSize: 13, fontWeight: 500, boxShadow: "0 8px 24px rgba(0,0,0,0.2)", animation: "slideIn 0.3s ease" }}>
            {notification.msg}
          </div>
        )}

        {/* DASHBOARD */}
        {page === "dashboard" && (
          <div>
            <h1 style={{ margin: "0 0 4px", fontSize: 24, fontWeight: 700, color: "#0f172a" }}>Good morning, {user.name.split(" ")[0]} 👋</h1>
            <p style={{ color: "#64748b", margin: "0 0 28px", fontSize: 14 }}>{new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</p>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 28 }}>
              {[
                { label: "Total Tasks", val: stats.total, icon: "📋", color: "#6366f1" },
                { label: "Completed", val: stats.done, icon: "✅", color: "#10b981" },
                { label: "In Progress", val: stats.inProg, icon: "🔄", color: "#3b82f6" },
                { label: "Overdue", val: stats.overdue, icon: "⚠️", color: "#ef4444" },
              ].map(s => (
                <div key={s.label} style={{ background: "#fff", borderRadius: 14, padding: "18px 20px", border: "1px solid #e2e8f0", display: "flex", alignItems: "center", gap: 14 }}>
                  <div style={{ width: 44, height: 44, borderRadius: 12, background: s.color + "18", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>{s.icon}</div>
                  <div>
                    <p style={{ color: "#64748b", margin: 0, fontSize: 11, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em" }}>{s.label}</p>
                    <p style={{ color: "#0f172a", margin: "2px 0 0", fontSize: 26, fontWeight: 700 }}>{s.val}</p>
                  </div>
                </div>
              ))}
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
              <div style={{ background: "#fff", borderRadius: 14, padding: "20px 22px", border: "1px solid #e2e8f0" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
                  <h3 style={{ margin: 0, fontSize: 15, fontWeight: 600, color: "#0f172a" }}>Completion Rate</h3>
                  <span style={{ fontSize: 22, fontWeight: 700, color: "#6366f1" }}>{stats.rate}%</span>
                </div>
                <div style={{ height: 8, background: "#f1f5f9", borderRadius: 99, overflow: "hidden", marginBottom: 12 }}>
                  <div style={{ height: "100%", background: "linear-gradient(90deg, #6366f1, #8b5cf6)", borderRadius: 99, width: `${stats.rate}%`, transition: "width 0.6s ease" }} />
                </div>
                <div style={{ display: "flex", gap: 16, marginTop: 16 }}>
                  {[{ l: "To Do", v: stats.todo, c: "#6b7280" }, { l: "In Progress", v: stats.inProg, c: "#3b82f6" }, { l: "Done", v: stats.done, c: "#10b981" }].map(s => (
                    <div key={s.l} style={{ flex: 1, textAlign: "center", padding: "10px 0", background: s.c + "10", borderRadius: 10 }}>
                      <p style={{ margin: 0, fontSize: 18, fontWeight: 700, color: s.c }}>{s.v}</p>
                      <p style={{ margin: 0, fontSize: 11, color: "#64748b" }}>{s.l}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div style={{ background: "#fff", borderRadius: 14, padding: "20px 22px", border: "1px solid #e2e8f0" }}>
                <h3 style={{ margin: "0 0 16px", fontSize: 15, fontWeight: 600, color: "#0f172a" }}>Recent Tasks</h3>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {myTasks.slice(-4).reverse().map(t => {
                    const assignee = DB.users.find(u => u.id === t.assigneeId);
                    const isOverdue = t.status !== "completed" && new Date(t.deadline) < new Date();
                    return (
                      <div key={t.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 10px", borderRadius: 8, background: "#f8fafc" }}>
                        <div onClick={() => toggleStatus(t)} style={{ width: 18, height: 18, borderRadius: 5, border: `2px solid ${t.status === "completed" ? "#10b981" : "#cbd5e1"}`, background: t.status === "completed" ? "#10b981" : "transparent", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                          {t.status === "completed" && <span style={{ color: "#fff", fontSize: 10 }}>✓</span>}
                        </div>
                        <span style={{ flex: 1, fontSize: 13, color: t.status === "completed" ? "#94a3b8" : "#0f172a", textDecoration: t.status === "completed" ? "line-through" : "none", fontWeight: 500 }}>{t.title}</span>
                        {isOverdue && <span style={{ fontSize: 10, color: "#ef4444", fontWeight: 600 }}>OVERDUE</span>}
                        {assignee && <Avatar user={assignee} size={22} />}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TASKS */}
        {page === "tasks" && (
          <div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
              <div>
                <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: "#0f172a" }}>Tasks</h1>
                <p style={{ color: "#64748b", margin: "4px 0 0", fontSize: 13 }}>{filteredTasks.length} tasks shown</p>
              </div>
              {user.role === "leader" && (
                <button onClick={() => { setEditTask(null); setTaskForm({ title: "", description: "", assigneeId: DB.users.filter(u => u.role === "member")[0]?.id || "", deadline: "", priority: "medium", category: "Engineering", status: "todo" }); setShowTaskModal(true); }} style={{ display: "flex", alignItems: "center", gap: 6, padding: "10px 18px", background: "linear-gradient(135deg, #6366f1, #8b5cf6)", border: "none", borderRadius: 10, color: "#fff", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
                  + New Task
                </button>
              )}
            </div>

            <div style={{ display: "flex", gap: 10, marginBottom: 20, flexWrap: "wrap" }}>
              <input value={taskFilter.search} onChange={e => setTaskFilter(f => ({ ...f, search: e.target.value }))} placeholder="🔍 Search tasks..." style={{ padding: "9px 14px", border: "1.5px solid #e2e8f0", borderRadius: 10, fontSize: 13, outline: "none", width: 220 }} />
              <select value={taskFilter.status} onChange={e => setTaskFilter(f => ({ ...f, status: e.target.value }))} style={{ padding: "9px 14px", border: "1.5px solid #e2e8f0", borderRadius: 10, fontSize: 13, background: "#fff", cursor: "pointer" }}>
                <option value="all">All Statuses</option>
                {Object.entries(STATUSES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
              <select value={taskFilter.priority} onChange={e => setTaskFilter(f => ({ ...f, priority: e.target.value }))} style={{ padding: "9px 14px", border: "1.5px solid #e2e8f0", borderRadius: 10, fontSize: 13, background: "#fff", cursor: "pointer" }}>
                <option value="all">All Priorities</option>
                {Object.entries(PRIORITIES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {filteredTasks.length === 0 && (
                <div style={{ textAlign: "center", padding: "60px 0", color: "#94a3b8" }}>
                  <div style={{ fontSize: 40, marginBottom: 12 }}>🗂️</div>
                  <p style={{ margin: 0, fontSize: 15 }}>No tasks found</p>
                </div>
              )}
              {filteredTasks.map(t => {
                const assignee = DB.users.find(u => u.id === t.assigneeId);
                const isOverdue = t.status !== "completed" && new Date(t.deadline) < new Date();
                return (
                  <div key={t.id} style={{ background: "#fff", borderRadius: 12, padding: "14px 18px", border: `1px solid ${isOverdue ? "#fecaca" : "#e2e8f0"}`, display: "flex", alignItems: "center", gap: 14, transition: "box-shadow 0.15s" }} onMouseEnter={e => e.currentTarget.style.boxShadow = "0 4px 12px rgba(0,0,0,0.06)"} onMouseLeave={e => e.currentTarget.style.boxShadow = "none"}>
                    <div onClick={() => toggleStatus(t)} style={{ width: 22, height: 22, borderRadius: 6, border: `2px solid ${t.status === "completed" ? "#10b981" : "#cbd5e1"}`, background: t.status === "completed" ? "#10b981" : t.status === "in-progress" ? "#3b82f611" : "transparent", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                      {t.status === "completed" && <span style={{ color: "#fff", fontSize: 12, fontWeight: 700 }}>✓</span>}
                      {t.status === "in-progress" && <div style={{ width: 8, height: 8, borderRadius: 2, background: "#3b82f6" }} />}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                        <span style={{ fontWeight: 600, fontSize: 14, color: t.status === "completed" ? "#94a3b8" : "#0f172a", textDecoration: t.status === "completed" ? "line-through" : "none" }}>{t.title}</span>
                        <Badge value={t.priority} map={PRIORITIES} />
                        <Badge value={t.status} map={STATUSES} />
                        {isOverdue && <span style={{ fontSize: 10, color: "#ef4444", fontWeight: 700, background: "#fef2f2", padding: "2px 6px", borderRadius: 20 }}>OVERDUE</span>}
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 12, fontSize: 11, color: "#94a3b8" }}>
                        <span>📁 {t.category}</span>
                        <span>📅 {t.deadline}</span>
                        {assignee && <span style={{ display: "flex", alignItems: "center", gap: 4 }}><Avatar user={assignee} size={16} />{assignee.name.split(" ")[0]}</span>}
                      </div>
                    </div>
                    {user.role === "leader" && (
                      <div style={{ display: "flex", gap: 6 }}>
                        <button onClick={() => openEdit(t)} style={{ padding: "6px 10px", background: "#f1f5f9", border: "none", borderRadius: 7, fontSize: 13, cursor: "pointer" }}>✏️</button>
                        <button onClick={() => deleteTask(t.id)} style={{ padding: "6px 10px", background: "#fef2f2", border: "none", borderRadius: 7, fontSize: 13, cursor: "pointer" }}>🗑️</button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ANALYTICS */}
        {page === "analytics" && user.role === "leader" && (
          <div>
            <h1 style={{ margin: "0 0 4px", fontSize: 22, fontWeight: 700, color: "#0f172a" }}>Analytics</h1>
            <p style={{ color: "#64748b", margin: "0 0 28px", fontSize: 13 }}>Team performance & task insights</p>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 20 }}>
              <div style={{ background: "#fff", borderRadius: 14, padding: "22px 24px", border: "1px solid #e2e8f0" }}>
                <h3 style={{ margin: "0 0 20px", fontSize: 15, fontWeight: 600, color: "#0f172a" }}>Team Member Performance</h3>
                {stats.byMember.map(m => (
                  <div key={m.name} style={{ marginBottom: 16 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <div style={{ width: 28, height: 28, borderRadius: "50%", background: m.color + "22", color: m.color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700 }}>{m.avatar}</div>
                        <span style={{ fontSize: 13, fontWeight: 500, color: "#0f172a" }}>{m.name}</span>
                      </div>
                      <span style={{ fontSize: 13, fontWeight: 600, color: m.color }}>{m.pct}%</span>
                    </div>
                    <div style={{ height: 6, background: "#f1f5f9", borderRadius: 99, overflow: "hidden" }}>
                      <div style={{ height: "100%", background: m.color, borderRadius: 99, width: `${m.pct}%`, transition: "width 0.6s ease" }} />
                    </div>
                    <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4 }}>
                      <span style={{ fontSize: 10, color: "#94a3b8" }}>{m.done} of {m.total} tasks done</span>
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ background: "#fff", borderRadius: 14, padding: "22px 24px", border: "1px solid #e2e8f0" }}>
                <h3 style={{ margin: "0 0 20px", fontSize: 15, fontWeight: 600, color: "#0f172a" }}>Tasks by Category</h3>
                {stats.byCategory.map((c, i) => {
                  const colors = ["#6366f1", "#10b981", "#f59e0b", "#ef4444", "#3b82f6", "#8b5cf6"];
                  const col = colors[i % colors.length];
                  const maxCat = Math.max(...stats.byCategory.map(x => x.count));
                  return (
                    <div key={c.cat} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
                      <span style={{ fontSize: 12, color: "#64748b", width: 80, flexShrink: 0 }}>{c.cat}</span>
                      <div style={{ flex: 1, height: 20, background: "#f1f5f9", borderRadius: 6, overflow: "hidden" }}>
                        <div style={{ height: "100%", background: col, borderRadius: 6, width: `${(c.count / maxCat) * 100}%`, transition: "width 0.6s ease", display: "flex", alignItems: "center", paddingLeft: 8 }}>
                          <span style={{ color: "#fff", fontSize: 10, fontWeight: 700 }}>{c.count}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div style={{ background: "#fff", borderRadius: 14, padding: "22px 24px", border: "1px solid #e2e8f0" }}>
              <h3 style={{ margin: "0 0 20px", fontSize: 15, fontWeight: 600, color: "#0f172a" }}>Overall Task Health</h3>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
                {[
                  { label: "Completion Rate", val: `${stats.rate}%`, sub: "of all tasks done", color: "#10b981", icon: "🎯" },
                  { label: "Overdue Tasks", val: stats.overdue, sub: "need attention", color: "#ef4444", icon: "🚨" },
                  { label: "Active Tasks", val: stats.inProg, sub: "in progress now", color: "#3b82f6", icon: "⚡" },
                  { label: "Pending Tasks", val: stats.todo, sub: "waiting to start", color: "#f59e0b", icon: "📌" },
                ].map(s => (
                  <div key={s.label} style={{ textAlign: "center", padding: "18px 12px", background: s.color + "09", borderRadius: 12, border: `1px solid ${s.color}22` }}>
                    <div style={{ fontSize: 28, marginBottom: 8 }}>{s.icon}</div>
                    <p style={{ margin: 0, fontSize: 26, fontWeight: 700, color: s.color }}>{s.val}</p>
                    <p style={{ margin: "4px 0 0", fontSize: 11, fontWeight: 600, color: "#0f172a" }}>{s.label}</p>
                    <p style={{ margin: "2px 0 0", fontSize: 10, color: "#94a3b8" }}>{s.sub}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TEAM */}
        {page === "team" && user.role === "leader" && (
          <div>
            <h1 style={{ margin: "0 0 4px", fontSize: 22, fontWeight: 700, color: "#0f172a" }}>Team</h1>
            <p style={{ color: "#64748b", margin: "0 0 28px", fontSize: 13 }}>Manage your team members</p>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
              {DB.users.filter(u => u.role === "member").map(member => {
                const mt = tasks.filter(t => t.assigneeId === member.id);
                const done = mt.filter(t => t.status === "completed").length;
                const inProg = mt.filter(t => t.status === "in-progress").length;
                const pct = mt.length > 0 ? Math.round((done / mt.length) * 100) : 0;
                return (
                  <div key={member.id} style={{ background: "#fff", borderRadius: 14, padding: "22px 20px", border: "1px solid #e2e8f0", textAlign: "center" }}>
                    <div style={{ display: "flex", justifyContent: "center", marginBottom: 12 }}>
                      <Avatar user={member} size={52} />
                    </div>
                    <h3 style={{ margin: "0 0 4px", fontSize: 15, fontWeight: 700, color: "#0f172a" }}>{member.name}</h3>
                    <p style={{ margin: "0 0 16px", fontSize: 12, color: "#94a3b8" }}>{member.email}</p>
                    <div style={{ display: "flex", justifyContent: "center", marginBottom: 14 }}>
                      <div style={{ position: "relative", width: 56, height: 56 }}>
                        <ProgressRing pct={pct} size={56} color={member.color} />
                        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: member.color }}>{pct}%</div>
                      </div>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 6 }}>
                      {[{ l: "Total", v: mt.length, c: "#6366f1" }, { l: "Done", v: done, c: "#10b981" }, { l: "Active", v: inProg, c: "#3b82f6" }].map(s => (
                        <div key={s.l} style={{ padding: "8px 4px", background: s.c + "10", borderRadius: 8 }}>
                          <p style={{ margin: 0, fontSize: 16, fontWeight: 700, color: s.c }}>{s.v}</p>
                          <p style={{ margin: 0, fontSize: 10, color: "#94a3b8" }}>{s.l}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </main>

      {/* Task Modal */}
      {showTaskModal && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 500, display: "flex", alignItems: "center", justifyContent: "center" }} onClick={e => e.target === e.currentTarget && setShowTaskModal(false)}>
          <div style={{ background: "#fff", borderRadius: 18, padding: "28px 28px", width: 500, maxHeight: "90vh", overflowY: "auto", boxShadow: "0 25px 60px rgba(0,0,0,0.25)" }}>
            <h2 style={{ margin: "0 0 22px", fontSize: 18, fontWeight: 700, color: "#0f172a" }}>{editTask ? "Edit Task" : "New Task"}</h2>
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {[
                { label: "Title *", key: "title", type: "text", placeholder: "Task title..." },
                { label: "Description", key: "description", type: "textarea", placeholder: "What needs to be done?" },
              ].map(f => (
                <div key={f.key}>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#374151", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>{f.label}</label>
                  {f.type === "textarea"
                    ? <textarea value={taskForm[f.key]} onChange={e => setTaskForm(p => ({ ...p, [f.key]: e.target.value }))} placeholder={f.placeholder} rows={3} style={{ width: "100%", padding: "10px 14px", border: "1.5px solid #e2e8f0", borderRadius: 10, fontSize: 13, resize: "vertical", outline: "none", boxSizing: "border-box", fontFamily: "inherit" }} />
                    : <input value={taskForm[f.key]} onChange={e => setTaskForm(p => ({ ...p, [f.key]: e.target.value }))} placeholder={f.placeholder} style={{ width: "100%", padding: "10px 14px", border: "1.5px solid #e2e8f0", borderRadius: 10, fontSize: 13, outline: "none", boxSizing: "border-box" }} />
                  }
                </div>
              ))}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#374151", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Assign To</label>
                  <select value={taskForm.assigneeId} onChange={e => setTaskForm(p => ({ ...p, assigneeId: e.target.value }))} style={{ width: "100%", padding: "10px 14px", border: "1.5px solid #e2e8f0", borderRadius: 10, fontSize: 13, background: "#fff" }}>
                    {DB.users.filter(u => u.role === "member").map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#374151", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Deadline</label>
                  <input type="date" value={taskForm.deadline} onChange={e => setTaskForm(p => ({ ...p, deadline: e.target.value }))} style={{ width: "100%", padding: "10px 14px", border: "1.5px solid #e2e8f0", borderRadius: 10, fontSize: 13, outline: "none", boxSizing: "border-box" }} />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#374151", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Priority</label>
                  <select value={taskForm.priority} onChange={e => setTaskForm(p => ({ ...p, priority: e.target.value }))} style={{ width: "100%", padding: "10px 14px", border: "1.5px solid #e2e8f0", borderRadius: 10, fontSize: 13, background: "#fff" }}>
                    {Object.entries(PRIORITIES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#374151", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Category</label>
                  <select value={taskForm.category} onChange={e => setTaskForm(p => ({ ...p, category: e.target.value }))} style={{ width: "100%", padding: "10px 14px", border: "1.5px solid #e2e8f0", borderRadius: 10, fontSize: 13, background: "#fff" }}>
                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>
              {editTask && (
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#374151", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Status</label>
                  <select value={taskForm.status} onChange={e => setTaskForm(p => ({ ...p, status: e.target.value }))} style={{ width: "100%", padding: "10px 14px", border: "1.5px solid #e2e8f0", borderRadius: 10, fontSize: 13, background: "#fff" }}>
                    {Object.entries(STATUSES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                  </select>
                </div>
              )}
              <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", paddingTop: 8 }}>
                <button onClick={() => setShowTaskModal(false)} style={{ padding: "10px 20px", background: "#f1f5f9", border: "none", borderRadius: 10, fontSize: 13, fontWeight: 600, cursor: "pointer", color: "#374151" }}>Cancel</button>
                <button onClick={handleSaveTask} style={{ padding: "10px 24px", background: "linear-gradient(135deg, #6366f1, #8b5cf6)", border: "none", borderRadius: 10, fontSize: 13, fontWeight: 600, cursor: "pointer", color: "#fff" }}>{editTask ? "Update Task" : "Create Task"}</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

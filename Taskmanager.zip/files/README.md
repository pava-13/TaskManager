# TaskFlow — Full-Stack Task Manager

A complete team task management system with role-based access, analytics, and real-time filtering.

---

## Architecture

```
taskflow/
├── frontend/          ← React app (TaskManager.jsx)
│   └── src/
│       └── App.jsx    ← paste TaskManager.jsx content here
├── backend/           ← Node.js + SQLite REST API
│   ├── server.js
│   └── package.json
└── README.md
```

---

## Database Schema (SQLite / adaptable to PostgreSQL or MySQL)

```sql
-- Users table: stores team members + leaders
CREATE TABLE users (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT    NOT NULL,
  email       TEXT    NOT NULL UNIQUE,
  password    TEXT    NOT NULL,           -- bcrypt hashed
  role        TEXT    NOT NULL DEFAULT 'member'  -- 'leader' | 'member'
               CHECK(role IN ('leader','member')),
  avatar      TEXT,                        -- 2-char initials e.g. "AR"
  color       TEXT    DEFAULT '#6366f1',  -- hex color for UI
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Tasks table: core task data
CREATE TABLE tasks (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  title       TEXT    NOT NULL,
  description TEXT,
  assignee_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  deadline    TEXT,                        -- ISO date string YYYY-MM-DD
  priority    TEXT    NOT NULL DEFAULT 'medium'
               CHECK(priority IN ('critical','high','medium','low')),
  status      TEXT    NOT NULL DEFAULT 'todo'
               CHECK(status IN ('todo','in-progress','completed')),
  category    TEXT    NOT NULL DEFAULT 'Engineering',
  created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Activity log: audit trail of all changes
CREATE TABLE activity_log (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER REFERENCES users(id),
  task_id     INTEGER REFERENCES tasks(id) ON DELETE CASCADE,
  action      TEXT    NOT NULL,           -- 'created'|'updated'|'deleted'|'status_changed'
  detail      TEXT,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);
```

---

## Setup & Run

### 1. Backend

```bash
cd backend
npm install
node server.js        # starts on http://localhost:3001
# or: npm run dev     # with auto-reload via nodemon
```

The SQLite database (`taskflow.db`) is auto-created with seed data on first run.

### 2. Frontend (React)

```bash
npx create-react-app frontend
cd frontend
# Replace src/App.js content with TaskManager.jsx
npm start             # starts on http://localhost:3000
```

To connect frontend to the live backend, replace the in-memory `DB` object in `TaskManager.jsx` with `fetch()` calls to `http://localhost:3001/api/...`.

---

## API Reference

All authenticated routes require: `Authorization: Bearer <jwt_token>`

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/auth/login` | Public | Login → returns JWT |
| GET | `/api/auth/me` | Any | Get current user |
| GET | `/api/users` | Any | List users (leaders see all) |
| POST | `/api/users` | Leader | Create user |
| DELETE | `/api/users/:id` | Leader | Delete user |
| GET | `/api/tasks` | Any | List tasks (filtered by role) |
| POST | `/api/tasks` | Leader | Create task |
| PATCH | `/api/tasks/:id` | Any | Update task (members: status only) |
| DELETE | `/api/tasks/:id` | Leader | Delete task |
| GET | `/api/analytics/summary` | Leader | Full analytics |
| GET | `/api/analytics/my` | Any | Personal stats |
| GET | `/api/activity` | Leader | Activity audit log |

### Example: Login

```javascript
const res = await fetch("http://localhost:3001/api/auth/login", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ email: "alex@team.io", password: "leader123" })
});
const { token, user } = await res.json();
localStorage.setItem("token", token);
```

### Example: Fetch tasks (authenticated)

```javascript
const token = localStorage.getItem("token");
const res = await fetch("http://localhost:3001/api/tasks?status=todo", {
  headers: { Authorization: `Bearer ${token}` }
});
const tasks = await res.json();
```

---

## Role Permissions

| Feature | Team Leader | Team Member |
|---------|-------------|-------------|
| See all tasks | ✅ | ❌ (own only) |
| Create tasks | ✅ | ❌ |
| Assign tasks | ✅ | ❌ |
| Edit tasks | ✅ | Status only |
| Delete tasks | ✅ | ❌ |
| View analytics | ✅ | Personal only |
| Manage team | ✅ | ❌ |

---

## Demo Accounts

| Email | Password | Role |
|-------|----------|------|
| alex@team.io | leader123 | Team Leader |
| jordan@team.io | member123 | Team Member |
| sam@team.io | member456 | Team Member |
| morgan@team.io | member789 | Team Member |

---

## Migrating to PostgreSQL

Replace `better-sqlite3` with `pg` (node-postgres) and adjust:
- `db.prepare(sql).get(...)` → `await pool.query(sql, params)`
- `INTEGER PRIMARY KEY AUTOINCREMENT` → `SERIAL PRIMARY KEY`
- `datetime('now')` → `NOW()`
- `PRAGMA foreign_keys = ON` → not needed (on by default in Postgres)
